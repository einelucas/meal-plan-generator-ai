// app/api/shopping-list/generate/route.ts
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import OpenAI from "openai";

const openai = new OpenAI({
  baseURL: "https://openrouter.ai/api/v1",
  apiKey: process.env.OPENROUTER_API_KEY,
});

export async function POST(request: Request) {
  const { userId } = await auth();
  if (!userId)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const { mealPlanId, mealPlan } = await request.json();

    // Se tem ID, busca do banco
    let planToProcess = mealPlan;
    if (mealPlanId) {
      const plan = await prisma.mealPlan.findUnique({
        where: { id: mealPlanId },
        include: { days: true },
      });
      if (!plan)
        return NextResponse.json(
          { error: "Plano não encontrado" },
          { status: 404 },
        );

      // Converter days array para objeto
      planToProcess = plan.days.reduce(
        (acc, day) => ({
          ...acc,
          [day.day]: {
            Breakfast: day.breakfast,
            Lunch: day.lunch,
            Dinner: day.dinner,
            Snacks: day.snacks,
          },
        }),
        {},
      );
    }

    const prompt = `
      Extraia TODOS os ingredientes deste plano alimentar de 7 dias.
      Agrupe por categoria (Hortifruti, Carnes, Laticínios, Grãos, Temperos, Outros).
      Calcule quantidades aproximadas para a semana toda.
      Retorne APENAS JSON com esta estrutura exata:
      
      {
        "categories": {
          "Hortifruti": ["2 kg de tomate", "1 maço de alface", ...],
          "Carnes": ["1 kg de peito de frango", "500g de carne moída", ...],
          "Laticínios": ["1 litro de leite", "200g de queijo", ...],
          "Grãos": ["500g de arroz", "250g de feijão", ...],
          "Temperos": ["alho", "cebola", "azeite", ...],
          "Outros": ["itens que não se encaixam acima"]
        }
      }
      
      Plano alimentar: ${JSON.stringify(planToProcess, null, 2)}
    `;

    const response = await openai.chat.completions.create({
      model: "openai/gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.3,
    });

    const content = response.choices[0].message.content;
    const shoppingList = JSON.parse(content.replace(/```json|```/g, ""));

    // Salvar no banco se veio de um plano salvo
    if (mealPlanId) {
      await prisma.shoppingList.create({
        data: {
          userId,
          mealPlanId,
          items: shoppingList,
        },
      });
    }

    return NextResponse.json(shoppingList);
  } catch (error) {
    console.error("Erro:", error);
    return NextResponse.json({ error: "Erro ao gerar lista" }, { status: 500 });
  }
}
