import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const { userId } = await auth();

  if (!userId) {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  }

  try {
    let preferences = await prisma.userPreferences.findUnique({
      where: { userId },
    });

    if (!preferences) {
      // Criar preferências padrão se não existir
      preferences = await prisma.userPreferences.create({
        data: { userId },
      });
    }

    return NextResponse.json(preferences);
  } catch (error) {
    console.error("Erro ao buscar preferências:", error);
    return NextResponse.json(
      { error: "Erro ao buscar preferências" },
      { status: 500 },
    );
  }
}

export async function PUT(request: Request) {
  const { userId } = await auth();

  if (!userId) {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  }

  try {
    const data = await request.json();

    // Campos permitidos
    const allowedFields = {
      dislikedFoods: data.dislikedFoods,
      preferredFoods: data.preferredFoods,
      maxPrepTime: data.maxPrepTime ? parseInt(data.maxPrepTime) : undefined,
      budgetLevel: data.budgetLevel,
      dietGoal: data.dietGoal,
    };

    // Remover undefined
    Object.keys(allowedFields).forEach(
      (key) => allowedFields[key] === undefined && delete allowedFields[key],
    );

    const updatedPreferences = await prisma.userPreferences.upsert({
      where: { userId },
      update: allowedFields,
      create: {
        userId,
        ...allowedFields,
      },
    });

    return NextResponse.json(updatedPreferences);
  } catch (error) {
    console.error("Erro ao atualizar preferências:", error);
    return NextResponse.json(
      { error: "Erro ao atualizar preferências" },
      { status: 500 },
    );
  }
}
