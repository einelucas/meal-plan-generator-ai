import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const { userId } = await auth();

  if (!userId) {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  }

  try {
    const profile = await prisma.profile.findUnique({
      where: { userId },
      select: {
        height: true,
        startWeight: true,
        targetWeight: true,
        currentWeight: true,
        dietType: true,
        cookingLevel: true,
      },
    });

    return NextResponse.json(profile || {});
  } catch (error) {
    console.error("Erro ao buscar dados físicos:", error);
    return NextResponse.json(
      { error: "Erro ao buscar dados" },
      { status: 500 },
    );
  }
}

export async function PUT(request: Request) {
  const { userId } = await auth();

  if (!userId) {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  }

  try {
    const data = await request.json();

    // Filtrar apenas campos válidos
    const updateData: any = {};

    if (data.height !== undefined) updateData.height = data.height;
    if (data.startWeight !== undefined)
      updateData.startWeight = data.startWeight;
    if (data.targetWeight !== undefined)
      updateData.targetWeight = data.targetWeight;
    if (data.currentWeight !== undefined)
      updateData.currentWeight = data.currentWeight;
    if (data.dietType !== undefined) updateData.dietType = data.dietType;
    if (data.cookingLevel !== undefined)
      updateData.cookingLevel = data.cookingLevel;

    const updatedProfile = await prisma.profile.update({
      where: { userId },
      data: updateData,
    });

    return NextResponse.json(updatedProfile);
  } catch (error) {
    console.error("Erro ao atualizar dados físicos:", error);
    return NextResponse.json(
      { error: "Erro ao atualizar dados" },
      { status: 500 },
    );
  }
}
