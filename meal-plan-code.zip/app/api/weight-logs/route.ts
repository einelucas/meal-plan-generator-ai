import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const { userId } = await auth();

  if (!userId) {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  }

  try {
    const weightLogs = await prisma.weightLog.findMany({
      where: { userId },
      orderBy: { date: "asc" },
      select: {
        id: true,
        weight: true,
        date: true,
        notes: true,
      },
    });

    return NextResponse.json(weightLogs);
  } catch (error) {
    console.error("Erro ao buscar logs de peso:", error);
    return NextResponse.json(
      { error: "Erro ao buscar histórico de peso" },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  const { userId } = await auth();

  if (!userId) {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  }

  try {
    const { weight, date, notes } = await request.json();

    if (!weight) {
      return NextResponse.json(
        { error: "Peso é obrigatório" },
        { status: 400 },
      );
    }

    const newLog = await prisma.weightLog.create({
      data: {
        userId,
        weight: parseFloat(weight),
        date: date ? new Date(date) : new Date(),
        notes,
      },
    });

    return NextResponse.json(newLog, { status: 201 });
  } catch (error) {
    console.error("Erro ao criar log de peso:", error);
    return NextResponse.json(
      { error: "Erro ao registrar peso" },
      { status: 500 },
    );
  }
}
