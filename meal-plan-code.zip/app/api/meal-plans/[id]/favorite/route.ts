// app/api/meal-plans/[id]/favorite/route.ts
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } },
) {
  const { userId } = await auth();
  if (!userId)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const { favorite } = await request.json();

    const updated = await prisma.mealPlan.update({
      where: {
        id: params.id,
        userId, // Garante que é do usuário
      },
      data: { favorite },
    });

    return NextResponse.json({ success: true, favorite: updated.favorite });
  } catch (error) {
    return NextResponse.json({ error: "Erro ao atualizar" }, { status: 500 });
  }
}
