// app/api/meal-plans/[id]/route.ts
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET(
  request: Request,
  { params }: { params: { id: string } },
) {
  const { userId } = await auth();
  if (!userId)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const plan = await prisma.mealPlan.findUnique({
      where: {
        id: params.id,
        userId,
      },
      include: { days: true },
    });

    if (!plan) {
      return NextResponse.json(
        { error: "Plano não encontrado" },
        { status: 404 },
      );
    }

    // 🔥 Parse dos JSONs
    const planWithDetails = {
      ...plan,
      days: plan.days.map((day) => ({
        ...day,
        breakfast: day.breakfast ? JSON.parse(day.breakfast) : null,
        lunch: day.lunch ? JSON.parse(day.lunch) : null,
        dinner: day.dinner ? JSON.parse(day.dinner) : null,
        snacks: day.snacks ? JSON.parse(day.snacks) : null,
      })),
    };

    return NextResponse.json({ plan: planWithDetails });
  } catch (error) {
    console.error("Erro ao buscar plano:", error);
    return NextResponse.json(
      { error: "Erro ao buscar plano" },
      { status: 500 },
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } },
) {
  const { userId } = await auth();
  if (!userId)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    await prisma.mealPlan.delete({
      where: {
        id: params.id,
        userId,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Erro ao deletar:", error);
    return NextResponse.json(
      { error: "Erro ao deletar plano" },
      { status: 500 },
    );
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } },
) {
  const { userId } = await auth();
  if (!userId)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await request.json();
    const { name, favorite } = body;

    const updateData: any = {};
    if (name !== undefined) updateData.name = name;
    if (favorite !== undefined) updateData.favorite = favorite;

    const updated = await prisma.mealPlan.update({
      where: {
        id: params.id,
        userId,
      },
      data: updateData,
    });

    return NextResponse.json({ success: true, plan: updated });
  } catch (error) {
    console.error("Erro ao atualizar:", error);
    return NextResponse.json(
      { error: "Erro ao atualizar plano" },
      { status: 500 },
    );
  }
}
