// app/api/meal-plans/[id]/share/route.ts
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function POST(
  request: Request,
  { params }: { params: { id: string } },
) {
  const { userId } = await auth();
  if (!userId)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    // Verificar se o plano existe e pertence ao usuário
    const plan = await prisma.mealPlan.findUnique({
      where: {
        id: params.id,
        userId,
      },
    });

    if (!plan) {
      return NextResponse.json(
        { error: "Plano não encontrado" },
        { status: 404 },
      );
    }

    // Criar link compartilhável
    const shared = await prisma.sharedPlan.create({
      data: {
        mealPlanId: params.id,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 dias
      },
    });

    const shareUrl = `${process.env.NEXT_PUBLIC_BASE_URL}/shared/${shared.shareToken}`;

    return NextResponse.json({
      success: true,
      shareUrl,
      shareToken: shared.shareToken,
    });
  } catch (error) {
    console.error("Erro ao compartilhar:", error);
    return NextResponse.json(
      { error: "Erro ao compartilhar" },
      { status: 500 },
    );
  }
}
