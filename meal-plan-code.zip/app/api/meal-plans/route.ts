// app/api/meal-plans/route.ts
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const { userId } = await auth();
  if (!userId)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const { mealPlan, dietType, calories, allergies, cuisine, snacks, name } =
      await request.json();

    // 🔥 Converter de português para inglês se necessário
    const dayMapping: { [key: string]: string } = {
      segunda: "Monday",
      terca: "Tuesday",
      quarta: "Wednesday",
      quinta: "Thursday",
      sexta: "Friday",
      sabado: "Saturday",
      domingo: "Sunday",
    };

    // 🔥 Criar o plano com TODOS os detalhes nutricionais
    const saved = await prisma.mealPlan.create({
      data: {
        userId,
        name: name || `Plano ${new Date().toLocaleDateString("pt-BR")}`,
        dietType,
        calories,
        allergies,
        cuisine,
        snacks,
        days: {
          create: Object.entries(mealPlan).map(
            ([dayPt, meals]: [string, any]) => {
              const dayEn = dayMapping[dayPt] || dayPt;

              return {
                day: dayEn,
                // 🔥 Salvar como JSON com todos os detalhes
                breakfast: JSON.stringify(meals.cafe || null),
                lunch: JSON.stringify(meals.almoco || null),
                dinner: JSON.stringify(meals.jantar || null),
                snacks: meals.lanches ? JSON.stringify(meals.lanches) : null,
              };
            },
          ),
        },
      },
      include: { days: true },
    });

    return NextResponse.json({ success: true, plan: saved });
  } catch (error) {
    console.error("Erro ao salvar:", error);
    return NextResponse.json({ error: "Erro ao salvar" }, { status: 500 });
  }
}

export async function GET(request: Request) {
  const { userId } = await auth();
  if (!userId)
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const includeFavorites = searchParams.get("favorites") === "true";

  try {
    const plans = await prisma.mealPlan.findMany({
      where: {
        userId,
        favorite: includeFavorites ? true : undefined,
      },
      include: { days: true },
      orderBy: { createdAt: "desc" },
    });

    // 🔥 Parse dos JSONs para retornar objetos completos
    const plansWithDetails = plans.map((plan) => ({
      ...plan,
      days: plan.days.map((day) => ({
        ...day,
        breakfast: day.breakfast ? JSON.parse(day.breakfast) : null,
        lunch: day.lunch ? JSON.parse(day.lunch) : null,
        dinner: day.dinner ? JSON.parse(day.dinner) : null,
        snacks: day.snacks ? JSON.parse(day.snacks) : null,
      })),
    }));

    return NextResponse.json({ plans: plansWithDetails });
  } catch (error) {
    console.error("Erro ao buscar:", error);
    return NextResponse.json({ error: "Erro ao buscar" }, { status: 500 });
  }
}
