// app/api/generate-mealplan/route.ts
import { NextResponse } from "next/server";
import OpenAI from "openai";
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";

const openai = new OpenAI({
  baseURL: "https://openrouter.ai/api/v1",
  apiKey: process.env.OPENROUTER_API_KEY,
});

export async function POST(request: Request) {
  console.log("=== API /api/generate-mealplan INICIADA ===");

  try {
    // 1. VERIFICAR AUTENTICAÇÃO
    const { userId } = await auth();
    if (!userId) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    // 2. BUSCAR DADOS REAIS DO USUÁRIO NO BANCO
    console.log("Buscando dados do usuário:", userId);
    
    const [profile, preferences] = await Promise.all([
      prisma.profile.findUnique({
        where: { userId },
        select: {
          height: true,
          currentWeight: true,
          targetWeight: true,
          dietType: true,
          cookingLevel: true,
        },
      }),
      prisma.userPreferences.findUnique({
        where: { userId },
        select: {
          dislikedFoods: true,
          preferredFoods: true,
          maxPrepTime: true,
          budgetLevel: true,
          dietGoal: true,
        },
      }),
    ]);

    console.log("Perfil encontrado:", profile ? "Sim" : "Não");
    console.log("Preferências encontradas:", preferences ? "Sim" : "Não");

    // 3. VALIDAR SE TEM DADOS MÍNIMOS
    if (!profile?.currentWeight || !profile?.targetWeight) {
      return NextResponse.json(
        { error: "Complete seus dados físicos no perfil primeiro" },
        { status: 400 },
      );
    }

    // 4. CALCULAR CALORIAS BASEADO EM DADOS REAIS
    const dailyCalories = calculateDailyCalories(
      profile.height || 170,
      profile.currentWeight,
      profile.targetWeight,
      profile.dietType || "balanceada"
    );

    // 5. PREPARAR PROMPT COM TODOS OS DADOS REAIS
    const prompt = `
      Você é um nutricionista profissional especializado em dietas personalizadas.
      
      DADOS REAIS DO USUÁRIO:
      - Peso atual: ${profile.currentWeight}kg
      - Peso meta: ${profile.targetWeight}kg
      - Altura: ${profile.height || 170}cm
      - Tipo de dieta preferido: ${profile.dietType || "balanceada"}
      - Nível na cozinha: ${profile.cookingLevel || "intermediário"}
      - Alimentos que não gosta: ${preferences?.dislikedFoods?.join(", ") || "nenhum"}
      - Alimentos que prefere: ${preferences?.preferredFoods?.join(", ") || "nenhum"}
      - Tempo máximo de preparo: ${preferences?.maxPrepTime || 30} minutos
      - Objetivo: ${preferences?.dietGoal || "perder peso"}
      
      Calorias diárias calculadas: ${dailyCalories} kcal
      
      IMPORTANTE: Crie um plano alimentar de 7 dias (segunda a domingo) que:
      1. Some aproximadamente ${dailyCalories} calorias por dia
      2. Distribuição de macros: 30% proteína, 40% carboidratos, 30% gordura
      3. Use alimentos comuns no Brasil
      4. Respeite as preferências e restrições do usuário
      5. Tempo de preparo máximo: ${preferences?.maxPrepTime || 30} minutos por refeição
      
      Para CADA refeição (café da manhã, almoço, jantar e lanches), forneça:
      - nome: nome da receita
      - descricao: descrição breve
      - calorias: número inteiro
      - proteina: gramas (número)
      - carboidratos: gramas (número)
      - gordura: gramas (número)
      - tempo_preparo: minutos (número)
      - dificuldade: "Fácil", "Médio" ou "Difícil"
      - emoji: um emoji representativo
      - ingredientes: array com lista de ingredientes
      
      Retorne APENAS um objeto JSON com esta estrutura:
      
      {
        "segunda": {
          "cafe": { ... },
          "almoco": { ... },
          "jantar": { ... },
          "lanches": [ { ... }, { ... } ] // array de lanches
        },
        "terca": { ... },
        "quarta": { ... },
        "quinta": { ... },
        "sexta": { ... },
        "sabado": { ... },
        "domingo": { ... }
      }
      
      Use dias em português (segunda, terca, quarta, quinta, sexta, sabado, domingo).
      Para cada refeição, use os campos em português: nome, descricao, calorias, proteina, carboidratos, gordura, tempo_preparo, dificuldade, emoji, ingredientes.
      
      NÃO INCLUA TEXTO ADICIONAL, APENAS O JSON.
    `;

    console.log("Prompt preparado, enviando para OpenRouter...");

    // 6. CHAMAR A IA
    const response = await openai.chat.completions.create({
      model: "openai/gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "Você é um assistente especializado em nutrição. Responda apenas com JSON válido em português do Brasil.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.5,
      max_tokens: 4000,
    });

    const aiContent = response.choices[0]?.message?.content;
    
    if (!aiContent) {
      throw new Error("Resposta vazia da IA");
    }

    console.log("Resposta recebida, processando...");

    // 7. LIMPAR E VALIDAR O JSON
    const cleanedContent = aiContent
      .replace(/```json\n?/g, "")
      .replace(/```\n?/g, "")
      .replace(/^\s*\{/, "{")
      .replace(/\}\s*$/, "}")
      .trim();

    let mealPlan;
    try {
      mealPlan = JSON.parse(cleanedContent);
      
      // Validar estrutura básica
      const requiredDays = ["segunda", "terca", "quarta", "quinta", "sexta", "sabado", "domingo"];
      const missingDays = requiredDays.filter(day => !mealPlan[day]);
      
      if (missingDays.length > 0) {
        console.warn("Dias faltando:", missingDays);
        // Completar dias faltando com estrutura vazia
        missingDays.forEach(day => {
          mealPlan[day] = mealPlan[day] || {
            cafe: { nome: "Dia não gerado", calorias: 0, proteina: 0, carboidratos: 0, gordura: 0 },
            almoco: { nome: "Dia não gerado", calorias: 0, proteina: 0, carboidratos: 0, gordura: 0 },
            jantar: { nome: "Dia não gerado", calorias: 0, proteina: 0, carboidratos: 0, gordura: 0 }
          };
        });
      }
      
    } catch (parseError) {
      console.error("Erro ao parsear JSON:", parseError);
      console.error("Conteúdo bruto:", aiContent);
      
      // Tentar extrair JSON
      const jsonMatch = cleanedContent.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          mealPlan = JSON.parse(jsonMatch[0]);
        } catch {
          return NextResponse.json(
            { error: "Formato inválido da resposta da IA" },
            { status: 500 },
          );
        }
      } else {
        return NextResponse.json(
          { error: "Resposta da IA não contém JSON válido" },
          { status: 500 },
        );
      }
    }

    // 8. CALCULAR TOTAIS PARA VALIDAÇÃO
    const totals = calculateDailyTotals(mealPlan);
    console.log("Totais calculados:", totals);

    // 9. RETORNAR SUCESSO COM OS DADOS REAIS
    return NextResponse.json({
      success: true,
      mealPlan,
      totals,
      userData: {
        calories: dailyCalories,
        dietType: profile.dietType,
        cookingLevel: profile.cookingLevel,
      },
    });

  } catch (error) {
    console.error("=== ERRO NA API ===");
    console.error("Erro:", error instanceof Error ? error.message : String(error));
    
    return NextResponse.json(
      { 
        error: "Erro ao gerar plano alimentar",
        details: error instanceof Error ? error.message : "Erro desconhecido"
      },
      { status: 500 },
    );
  }
}

// Função para calcular calorias diárias baseado em dados reais
function calculateDailyCalories(
  height: number,
  currentWeight: number,
  targetWeight: number,
  dietType: string
): number {
  // Fórmula de Mifflin-St Jeor (assumindo idade 30, sexo masculino como base)
  // Em produção, você deve ter idade e sexo no perfil
  const tmb = 10 * currentWeight + 6.25 * height - 5 * 30 + 5;
  
  // Fator de atividade (assumindo moderado)
  const fatorAtividade = 1.55;
  const mantença = Math.round(tmb * fatorAtividade);
  
  // Ajuste baseado no objetivo
  if (targetWeight < currentWeight) {
    // Quer emagrecer
    return Math.round(mantença - 500);
  } else if (targetWeight > currentWeight) {
    // Quer ganhar massa
    return Math.round(mantença + 300);
  } else {
    // Quer manter
    return mantença;
  }
}

// Função para calcular totais diários
function calculateDailyTotals(mealPlan: any) {
  const days = ["segunda", "terca", "quarta", "quinta", "sexta", "sabado", "domingo"];
  const totals: any = {};
  
  for (const day of days) {
    const dayPlan = mealPlan[day];
    if (!dayPlan) continue;
    
    let totalCalories = 0;
    let totalProtein = 0;
    let totalCarbs = 0;
    let totalFat = 0;
    
    // Soma café
    if (dayPlan.cafe) {
      totalCalories += dayPlan.cafe.calorias || 0;
      totalProtein += dayPlan.cafe.proteina || 0;
      totalCarbs += dayPlan.cafe.carboidratos || 0;
      totalFat += dayPlan.cafe.gordura || 0;
    }
    
    // Soma almoço
    if (dayPlan.almoco) {
      totalCalories += dayPlan.almoco.calorias || 0;
      totalProtein += dayPlan.almoco.proteina || 0;
      totalCarbs += dayPlan.almoco.carboidratos || 0;
      totalFat += dayPlan.almoco.gordura || 0;
    }
    
    // Soma jantar
    if (dayPlan.jantar) {
      totalCalories += dayPlan.jantar.calorias || 0;
      totalProtein += dayPlan.jantar.proteina || 0;
      totalCarbs += dayPlan.jantar.carboidratos || 0;
      totalFat += dayPlan.jantar.gordura || 0;
    }
    
    // Soma lanches
    if (dayPlan.lanches && Array.isArray(dayPlan.lanches)) {
      dayPlan.lanches.forEach((snack: any) => {
        totalCalories += snack.calorias || 0;
        totalProtein += snack.proteina || 0;
        totalCarbs += snack.carboidratos || 0;
        totalFat += snack.gordura || 0;
      });
    }
    
    totals[day] = {
      calorias: Math.round(totalCalories),
      proteina: Math.round(totalProtein),
      carboidratos: Math.round(totalCarbs),
      gordura: Math.round(totalFat),
    };
  }
  
  return totals;
}