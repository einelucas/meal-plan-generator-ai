// types/api.ts
import { WeeklyPlan, SavedPlan } from "./mealplan";
import { PhysicalData, UserPreferences } from "./profile";

// 🔥 Respostas padrão da API
export interface ApiResponse<T = any> {
  success?: boolean;
  error?: string;
  data?: T;
}

// 🔥 Respostas específicas
export interface MealPlansResponse {
  plans: SavedPlan[];
}

export interface SingleMealPlanResponse {
  plan: SavedPlan;
}

export interface PhysicalDataResponse extends PhysicalData {}

export interface PreferencesResponse extends UserPreferences {}

// 🔥 Requests
export interface UpdatePhysicalDataRequest extends Partial<PhysicalData> {}

export interface UpdatePreferencesRequest extends Partial<UserPreferences> {}

export interface SaveMealPlanRequest {
  mealPlan: WeeklyPlan;
  dietType: string;
  calories: number;
  allergies?: string;
  cuisine?: string;
  snacks: boolean;
  name?: string;
}
