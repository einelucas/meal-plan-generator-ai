// types/meal-plan.ts

// 🔥 Interface principal para uma refeição
export interface Meal {
  // Informações básicas
  nome: string;
  descricao: string;
  emoji: string;

  // Informações nutricionais (OBRIGATÓRIAS)
  calorias: number;
  proteina: number; // em gramas
  carboidratos: number; // em gramas
  gordura: number; // em gramas

  // Preparo
  tempo_preparo: number; // em minutos
  dificuldade: "Fácil" | "Médio" | "Difícil";

  // Ingredientes
  ingredientes: string[];

  // Metadados (opcionais)
  id?: string;
  rating?: number;
  is_favorite?: boolean;
  is_completed?: boolean;
}

// 🔥 Interface para o plano de um dia
export interface DayPlan {
  cafe: Meal | null;
  almoco: Meal | null;
  jantar: Meal | null;
  lanches: Meal[]; // Array de lanches (pode ser vazio)
}

// 🔥 Interface para o plano semanal completo
export interface WeeklyPlan {
  segunda: DayPlan;
  terca: DayPlan;
  quarta: DayPlan;
  quinta: DayPlan;
  sexta: DayPlan;
  sabado: DayPlan;
  domingo: DayPlan;
}

// 🔥 Interface para totais diários
export interface DailyTotals {
  calorias: number;
  proteina: number;
  carboidratos: number;
  gordura: number;
}

// 🔥 Interface para totais da semana
export interface WeeklyTotals {
  [day: string]: DailyTotals;
}

// 🔥 Interface para o plano salvo no banco
export interface SavedPlan {
  id: string;
  name: string;
  dietType: string;
  calories: number;
  allergies?: string;
  cuisine?: string;
  snacks: boolean;
  favorite: boolean;
  createdAt: string;
  days: Array<{
    id: string;
    day: string;
    breakfast: Meal | null;
    lunch: Meal | null;
    dinner: Meal | null;
    snacks: Meal[] | null;
  }>;
}

// 🔥 Interface para o input de geração de plano
export interface GeneratePlanInput {
  dietType: string;
  calories?: number; // Opcional - pode ser calculado pelo backend
  allergies?: string;
  cuisine?: string;
  snacks: boolean;
}

// 🔥 Interface para resposta da API de geração
export interface GeneratePlanResponse {
  success: boolean;
  mealPlan: WeeklyPlan;
  totals: WeeklyTotals;
  userData: {
    calories: number;
    dietType: string;
    cookingLevel: string;
  };
  error?: string;
  details?: string;
}
