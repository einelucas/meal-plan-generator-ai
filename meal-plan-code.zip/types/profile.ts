// types/profile.ts

// 🔥 Interface para dados físicos do usuário
export interface PhysicalData {
  height?: number; // altura em cm
  startWeight?: number; // peso inicial em kg
  targetWeight?: number; // peso meta em kg
  currentWeight?: number; // peso atual em kg
  dietType?: string; // tipo de dieta
  cookingLevel?: string; // nível na cozinha
}

// 🔥 Interface para preferências alimentares
export interface UserPreferences {
  dislikedFoods: string[]; // alimentos que não gosta
  preferredFoods: string[]; // alimentos que prefere
  maxPrepTime?: number; // tempo máximo de preparo em minutos
  budgetLevel?: "low" | "medium" | "high";
  dietGoal?: "perder peso" | "ganhar massa" | "manter";
}

// 🔥 Interface completa do perfil
export interface UserProfile {
  id: string;
  userId: string;
  email: string;
  subscriptionTier?: string;
  subscriptionActive: boolean;
  physicalData: PhysicalData;
  preferences: UserPreferences;
  createdAt: string;
  updatedAt: string;
}
